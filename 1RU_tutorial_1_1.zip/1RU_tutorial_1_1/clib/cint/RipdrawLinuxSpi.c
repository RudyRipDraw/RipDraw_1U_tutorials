//	Copyright: 
//
//	Version: 
//
//	supports Linux only

#include <linux/spi/spidev.h>
#include "../common/Ripdraw.h"

typedef struct _RdInterfaceLinuxSpi
{
	int handle;
} RdInterfaceLinuxSpi;

// FIXME: move inside the above struct
static unsigned char mode = 1; /* mode =1 for RipDraw 1U, mode = 0 for RipDraw 7" */
static unsigned char bits = 8;
static unsigned int speed = 1000000;

static struct spi_ioc_transfer xfer;

// write data to spi
static int RipdrawLinuxSpiWrite(RdInterface* rdi, RdByte* dataPtr, int dataLen)
{
	_RD_CHECK_INTERFACE();
	int bytesWrite = 0;

	xfer.tx_buf = (unsigned long) dataPtr;
	xfer.rx_buf = (unsigned long) NULL;
	xfer.len = dataLen;

	bytesWrite = ioctl(((RdInterfaceLinuxSpi*) rdi->extint)->handle, SPI_IOC_MESSAGE(1), &xfer);
	if (bytesWrite < dataLen)
	{
		perror("SPI_IOC_MESSAGE failed.\n");
		return (dataLen - bytesWrite);
	}
	return 0;
}

// read data from spi
static int RipdrawLinuxSpiRead(RdInterface* rdi, RdByte* dataPtr, int dataLen)
{
	_RD_CHECK_INTERFACE();
	int bytesRead = 0;

	xfer.tx_buf = (unsigned long) NULL;
	xfer.rx_buf = (unsigned long) dataPtr;
	xfer.len = dataLen;

	bytesRead = ioctl(((RdInterfaceLinuxSpi*) rdi->extint)->handle, SPI_IOC_MESSAGE(1), &xfer);
	if (bytesRead < 0)
	{
		perror("SPI_IOC_MESSAGE");
		return bytesRead;
	}
	return 0;
}

// close spi port
static int RipdrawLinuxSpiClose(RdInterface* rdi)
{
	RdInterfaceLinuxSpi* extint = (RdInterfaceLinuxSpi*)rdi->extint;
	_RD_CHECK_INTERFACE();

	rdi->isOpen = 0;
	close(extint->handle);
	free(extint);

	return 0;
}

// open the spi port 
int RipdrawLinuxSpiInit(RdInterface* rdi, char* portName)
{
	int ret = 0;
	int handle;

	xfer.speed_hz = speed;
	xfer.bits_per_word = bits;
	xfer.delay_usecs = 0;
	xfer.cs_change = 0;

	if (rdi == NULL) 
	{
		RD_ERR("interface should not NULL");
		return RdErrorInterfaceNull;
	}

	handle = open(portName, O_RDWR | O_SYNC);
	if (handle < 0) 
	{
		RD_ERR("port open failed");
		return RdErrorPortOpenFailed;
	}

	ret = ioctl(handle, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
	{
		RD_ERR("can't set spi mode");
	}
	
	ret = ioctl(handle, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
	{
		RD_ERR("can't get spi mode");
	}
	
	ret = ioctl(handle, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
	{
		RD_ERR("can't set bits per word");
	}
	
	ret = ioctl(handle, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
	{
		RD_ERR("can't get bits per word");
	}
	
	ret = ioctl(handle, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
	{
		RD_ERR("can't set max speed hz");
	}
	
	ret = ioctl(handle, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
	{
		RD_ERR("can't get max speed hz");
	}
		
	RD_INFO("%s :spi mode %d,bits : %d , speed : %f kHz max\n", portName, mode, bits,(float) speed/1000);

	rdi->extint = malloc(sizeof(RdInterfaceLinuxSpi));

	if (!rdi->extint) 
	{
		close(handle);
		RD_ERR("external interface data not allocated");
		return RdErrorExtintAllocFailed;
	}

	rdi->isOpen = 1;
	rdi->extIntType = RD_INTERFACE_TYPE_SPI;
	((RdInterfaceLinuxSpi*)rdi->extint)->handle = handle;

	RD_INFO("handle of rdi->extint->handle = %d and local handle= %d\n", ((RdInterfaceLinuxSpi*)rdi->extint)->handle, handle);

	rdi->write = RipdrawLinuxSpiWrite;
	rdi->read = RipdrawLinuxSpiRead;
	rdi->close = RipdrawLinuxSpiClose;

	RdSetRetryCntAndDelay(rdi, RD_INTERFACE_RESPONSE_RETRY_COUNT_DEFAULT, RD_INTERFACE_RESPONSE_RETRY_DELAY_DEFAULT);
	return (ret);
}

